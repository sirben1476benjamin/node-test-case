module.exports = {
    secret: "benjamin-secret-key"
  };