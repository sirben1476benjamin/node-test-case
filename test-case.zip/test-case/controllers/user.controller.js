exports.viewPictureUpload = async (req, res) => {
    const db = require("../models");
    const User = db.user;
   
    User.findByPk(req.params.userId).then((resp) => {
      let userData = {
        picture: "../uploads/images/"+resp.picture,
      };
      res.status(200).json({
        data: userData,
      });
    });
};

exports.userBoard = async (req, res) => {
  const db = require("../models");
  const User = db.user;
  User.findByPk(req.userId).then((user) => {
    let userData = {
      id: req.userId,
      email: user.email,
      picture: user.picture,
      username: user.username,
    };
    res.status(200).json({
      data: userData,
    });
  });
};

exports.userPictureUpdate = async (req, res, next) => {
  const db = require("../models");
  const helpers = require("../helpers");
  const multer = require("multer");
  const path = require("path");

  const User = db.user;
  const userId = req.userId;
  const user = await User.findByPk(req.userId);
  const body = req.body;

  const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, "../uploads/images");
    },

    // By default, multer removes file extensions so let's add them back
    filename: function (req, file, cb) {
      cb(
        null,
        file.fieldname + "-" + Date.now() + path.extname(file.originalname)
      );
    },
  });

  try {
    if (user) {
      let upload = multer({
        storage: storage,
        fileFilter: helpers.imageFilter,
      }).single("picture");

      upload(req, res, function (err) {
        if (req.fileValidationError) {
          return res.send(req.fileValidationError);
        } else if (!req.file) {
          return res.send("Please select an image to upload");
        } else if (err instanceof multer.MulterError) {
          return res.send(err);
        } else if (err) {
          return res.send(err);
        }

        let picture = req.file["picture"]
          ? req.file["picture"][0].filename
          : null;
        if (user.picture) {
          if (picture) {
            const pathImagePreview =
              path.join(storage.destination) + user.picture;
            fs.exists(pathImagePreview, (exists) => {
              if (exists) fs.unlinkSync(pathImagePreview);
            });
          } else {
            picture = user.picture;
          }
        }

        User.update(userId, {
          picture: body.picture,
        });
        res.status(200).json({
          message: "upload successful",
        });
      });
    } else {
      throw new Error("kindly confirm that picture image is uploaded!");
    }
  } catch (error) {
    res.status(500).send(error.message);
  }
};
